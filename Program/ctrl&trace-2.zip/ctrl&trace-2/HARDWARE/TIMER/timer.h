#ifndef _TIMER_H
#define _TIMER_H
#include "sys.h"


extern u8  TIM5CH1_CAPTURE_STA;	//���벶��״̬		    
extern u32 TIM5CH1_CAPTURE_VAL;


void TIM3_Int_Init(u16 arr,u16 psc);

void TIM5_CH1_Cap_Init(u32 arr,u16 psc);

void TIM4_PWM_init(u16 arr,u16 psc);

void TIM13_PWM_init(u16 arr,u16 psc);

	
#endif

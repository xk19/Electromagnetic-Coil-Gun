#ifndef _LCD_H
#define _LCD_H
#include "include.h"

#define LCD_DC	PTC19_OUT  
#define LCD_RST	PTC18_OUT 
#define LCD_SDA	PTC17_OUT  
#define LCD_SCL	PTC16_OUT  

#define X_WIDTH 128
#define Y_WIDTH 64


extern void LCD_Init(void);
extern void LCD_CLS(void);
void LCD_WrDat(unsigned char data);
void LCD_Set_Pos(unsigned char x, unsigned char y);
extern void LCD_P6x8Str(unsigned char x,unsigned char y,unsigned char ch[]);
extern void LCD_P8x16Str(unsigned char x,unsigned char y,unsigned char ch[]);
extern void LCD_P14x16Str(unsigned char x,unsigned char y,unsigned char ch[]);
extern void LCD_Print(unsigned char x, unsigned char y, unsigned char ch[]);
extern void LCD_PutPixel(unsigned char x,unsigned char y);
extern void LCD_Rectangle(unsigned char x1,unsigned char y1,unsigned char x2,unsigned char y2,unsigned char gif);
extern void Draw_LibLogo(void);
extern void Draw_BMP(unsigned char x0,unsigned char y0,unsigned char x1,unsigned char y1,unsigned char * bmp); 
void Draw_Frame(void);
void LCD_Show_Frame94(void);
#endif


#ifndef _CONTROL_H
#define _CONTROL_H
#include "include.h"


//����ṹ��
struct motor
{
  int16 Pluse;
  int16 SetPoint;
  float P;
  float I;
  float D;
  int16 LastError;
  int16 PreError;
  int16 Out;
  int16 PWM;
};


//��������
void PID_init(void);
void Motor_Init(void);
void Motor_Control(void);
void Stand_Balance(void);
void balance(float Angle,float Gyro);

















#endif

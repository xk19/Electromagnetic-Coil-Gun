#ifndef _DEBUG_H_
#define _DEBUG_H_

#include "include.h"

void info_show();
void Key_scan();












#endif
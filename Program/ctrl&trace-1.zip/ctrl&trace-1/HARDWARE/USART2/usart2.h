#ifndef __USART2_H
#define __USART2_H 
#include "sys.h"
#include "stdio.h"	  

void usart2_init(u32 pclk1,u32 bound); 
#endif	   
















